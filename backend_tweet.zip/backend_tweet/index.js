const { Server } = require("socket.io");
const axios = require("axios");
const io = new Server(4001, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"],
  },
});

console.log("started")

/* io.on('tweetid', (id) => {
    console.log(id);
    getTweet(id);
  }); */

  io.on('connection', (socket) => {
    console.log('un utilisateur c\'est connecter')

    socket.on('tweetid', (id) => {
        console.log(id);
        getTweet(id);
      });

      function getTweet(id) {

        var config = {
          method: 'get',
          url: `https://api.twitter.com/2/tweets/${id}?tweet.fields=author_id%2Cattachments%2Ccreated_at%2Cid&expansions=author_id&user.fields=name%2Cprofile_image_url%2Cusername%2Cverified%2Cdescription`,
          headers: { 
            'Authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAACDrhQEAAAAA2YpvFvE50K3CSioGv9PcHVYNon4%3DO6NTmye8pE4f4P1lTJ7kWxueFMZLUY3jdJFabRtI6KnXAazqb1', 
          }
        };
        
        axios(config)
        .then(function (res) {
          console.log(JSON.stringify(res.data));
          socket.emit('tweetresponse', res.data)
        })
        .catch(function (error) {
          console.log(error);
        });
    }
})

